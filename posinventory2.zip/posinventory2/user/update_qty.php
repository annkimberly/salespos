<?php
	if(isset($_POST['change'])){
		$qty=$_POST['quantity'];
	}


?>